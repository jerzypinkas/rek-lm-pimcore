<?php

return [
    "brick" => [
        "standard-teaser-row" => TRUE,
        "wysiwyg" => TRUE,
        "featurette" => TRUE,
        "video" => TRUE,
        "pdf" => TRUE,
        "gallery-folder" => TRUE,
        "gallery-single-images" => TRUE,
        "image" => TRUE,
        "blockquote" => TRUE,
        "image-hotspot" => TRUE,
        "image-hotspot-marker" => TRUE,
        "gallery-carousel" => TRUE,
        "headlines" => TRUE,
        "text-accordion" => TRUE,
        "horizontal-line" => TRUE,
        "icon-teaser-row" => TRUE,
        "tabbed-slider-text" => TRUE,
        "wysiwyg-with-images" => TRUE
    ],
    "bundle" => [
        "Pimcore\\Bundle\\EcommerceFrameworkBundle\\PimcoreEcommerceFrameworkBundle" => FALSE,
        "Pimcore\\Bundle\\DataHubBundle\\PimcoreDataHubBundle" => TRUE
    ]
];
