# CAUTION: This package is deprecated since Flysystem 3.0 Instead, use the [Flysystem for SFTP v3](https://github.com/thephpleague/flysystem-sftp-v3)

## Sub-split of Flysystem for SFTP using phpseclib2.

> ⚠️ this is a sub-split, for pull requests and issues, visit: https://github.com/thephpleague/flysystem

```bash
composer require league/flysystem-sftp
```

View the [documentation](https://flysystem.thephpleague.com/v2/docs/adapter/sftp/).
